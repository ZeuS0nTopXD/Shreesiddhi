require('dotenv').config({ path: 'adminpass.env' });
const express = require("express");
const path = require("path");
const fs = require("fs");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const session = require("express-session");

const app = express();
const PORT = process.env.PORT || 3000;

// ==========================
// ⚙️ Middleware
// ==========================
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Session setup
app.use(session({
  secret: process.env.SESSION_SECRET || "supersecretkey",
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60 * 60 * 1000, secure: false } // 1 hour
}));

// Simple request logger
app.use((req, _res, next) => {
  console.log(`${new Date().toISOString()} ➜ ${req.method} ${req.url}`);
  next();
});

// ==========================
// 💳 Razorpay Setup
// ==========================
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || "your_key_id",
  key_secret: process.env.RAZORPAY_KEY_SECRET || "your_key_secret",
});

// ==========================
// 🔐 Admin Credentials
// ==========================
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "password";

// ==========================
// 🔧 Helpers
// ==========================
function filePathOf(name) { return path.join(__dirname, name); }
function backupPathOf(name) { return path.join(__dirname, "backup", name); }

function ensureJsonFile(name) {
  const fp = filePathOf(name);
  if (!fs.existsSync(fp)) fs.writeFileSync(fp, "[]");
  return fp;
}

function readJsonArray(name) {
  const fp = ensureJsonFile(name);
  try {
    const raw = fs.readFileSync(fp, "utf8") || "[]";
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error(`JSON parse error in ${name}:`, e.message);
    return [];
  }
}

function pushAppointment(obj) {
  const arr = readJsonArray("appointments.json");
  const newAppointment = {
    id: `apt_${Date.now()}`,
    name: obj.name,
    email: obj.email,
    phone: obj.phone,
    bookingType: obj.bookingType,
    fee: Number(obj.fee) || 0,
    date: obj.date,
    message: obj.message || "",
    payment_id: obj.payment_id || null,
    order_id: obj.order_id || null,
    timestamp: new Date().toISOString(),
  };
  arr.push(newAppointment);
  fs.writeFileSync(filePathOf("appointments.json"), JSON.stringify(arr, null, 2));
  return newAppointment;
}

function pushFeedback(obj) {
  const arr = readJsonArray("feedback.json");
  const newFeedback = {
    id: `fb_${Date.now()}`,
    name: obj.name,
    email: obj.email,
    message: obj.message,
    timestamp: new Date().toISOString(),
  };
  arr.push(newFeedback);
  fs.writeFileSync(filePathOf("feedback.json"), JSON.stringify(arr, null, 2));
  return newFeedback;
}

function clearFile(name) {
  const fp = filePathOf(name);
  const bp = backupPathOf(name);
  fs.mkdirSync(path.dirname(bp), { recursive: true });
  const current = fs.readFileSync(fp, "utf8");
  fs.writeFileSync(bp, current);
  fs.writeFileSync(fp, "[]");
}

function undoClear(name) {
  const fp = filePathOf(name);
  const bp = backupPathOf(name);
  if (!fs.existsSync(bp)) return false;
  const backup = fs.readFileSync(bp, "utf8");
  fs.writeFileSync(fp, backup);
  return true;
}

// ==========================
// 🌐 Appointment & Feedback Routes
// ==========================
app.get("/api/hello", (_req, res) => {
  res.json({ message: "Hello from the Backend 👋" });
});

app.post("/api/appointment", (req, res) => {
  try {
    const saved = pushAppointment(req.body);
    res.json({ status: "success", type: "appointment", data: saved });
  } catch (e) {
    console.error("Save appointment error:", e);
    res.status(500).json({ error: "Could not save appointment" });
  }
});

app.post("/api/feedback", (req, res) => {
  try {
    const saved = pushFeedback(req.body);
    res.json({ status: "success", type: "feedback", data: saved });
  } catch (e) {
    console.error("Save feedback error:", e);
    res.status(500).json({ error: "Could not save feedback" });
  }
});

app.get("/api/appointments", (_req, res) => res.json(readJsonArray("appointments.json")));
app.get("/api/feedbacks", (_req, res) => res.json(readJsonArray("feedback.json")));

app.delete("/api/appointments", (_req, res) => {
  try {
    clearFile("appointments.json");
    res.json({ status: "success", message: "All appointments cleared. You can undo." });
  } catch {
    res.status(500).json({ error: "Could not clear appointments" });
  }
});

app.delete("/api/feedbacks", (_req, res) => {
  try {
    clearFile("feedback.json");
    res.json({ status: "success", message: "All feedback cleared. You can undo." });
  } catch {
    res.status(500).json({ error: "Could not clear feedback" });
  }
});

app.post("/api/appointments/undo", (_req, res) => {
  if (undoClear("appointments.json")) res.json({ status: "success", message: "Appointments restored from backup" });
  else res.status(400).json({ error: "No backup available" });
});

app.post("/api/feedbacks/undo", (_req, res) => {
  if (undoClear("feedback.json")) res.json({ status: "success", message: "Feedback restored from backup" });
  else res.status(400).json({ error: "No backup available" });
});

// ==========================
// 🔐 Admin Login / Logout
// ==========================
app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    res.json({ success: true });
  } else {
    res.json({ success: false });
  }
});

app.get("/api/admin/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: "Logout failed" });
    res.redirect("/admin/admin-login.html");
  });
});

function requireAdmin(req, res, next) {
  if (req.session.isAdmin) next();
  else res.redirect("/admin/admin-login.html");
}

// ==========================
// Admin Pages
// ==========================
app.get("/admin/dashboard", requireAdmin, (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin", "admindash.html"));
});

app.get("/admin/appointments", requireAdmin, (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin", "admindash.html"));
});

app.get("/admin/feedback", requireAdmin, (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin", "afeedback.html"));
});

app.get("/admin-login.html", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin", "admin-login.html"));
});

// ==========================
// 💳 Payment Routes
// ==========================
app.post("/api/payment/order", async (req, res) => {
  try {
    const { amount } = req.body;
    const options = { amount: amount * 100, currency: "INR", receipt: `rcpt_${Date.now()}` };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (err) {
    console.error("Error creating order:", err);
    res.status(500).json({ error: "Payment order failed" });
  }
});

app.post("/api/payment/verify", (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, appointment } = req.body;
    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto.createHmac("sha256", razorpay.key_secret).update(body.toString()).digest("hex");

    if (expectedSignature === razorpay_signature) {
      const saved = pushAppointment({ ...appointment, payment_id: razorpay_payment_id, order_id: razorpay_order_id });
      res.json({ status: "success", message: "Payment verified and appointment saved", data: saved });
    } else {
      res.status(400).json({ error: "Invalid payment signature" });
    }
  } catch (err) {
    console.error("Payment verification error:", err);
    res.status(500).json({ error: "Payment verification failed" });
  }
});

// ==========================
// 🚀 Start Server
// ==========================
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});